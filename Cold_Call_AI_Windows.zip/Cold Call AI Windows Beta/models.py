"""
Model management for Ollama and Together.ai
Fetches available models and handles model selection
"""

from typing import List, Dict, Optional
from account_policy import FREE_TIER_TOGETHER_MODEL


def normalize_ollama_base_url(url: str) -> str:
    """Return a clean Ollama base URL without a trailing /api segment."""
    base_url = str(url or "http://localhost:11434").strip().rstrip("/")
    if base_url.endswith("/api"):
        base_url = base_url[:-4].rstrip("/")
    return base_url or "http://localhost:11434"


class ModelManager:
    """Manage available models from different backends"""

    # Together.ai models (these are relatively static)
    TOGETHER_MODELS = {
        FREE_TIER_TOGETHER_MODEL: "Llama 3 8B Lite (Free Tier)",
        "meta-llama/Llama-3.3-70B-Instruct-Turbo": "Llama 3.3 70B (Most Powerful)",
        "Qwen/Qwen2.5-7B-Instruct-Turbo": "Qwen 2.5 7B (Fast & Reliable)",
        "mistralai/Mistral-7B-Instruct-v0.3": "Mistral 7B v0.3 (Serverless)",
        "mistralai/Mixtral-8x7B-Instruct-v0.1": "Mixtral 8x7B (Advanced)",
    }

    def __init__(self, config):
        self.config = config

    def get_ollama_models(self) -> List[Dict[str, str]]:
        """Fetch available models from Ollama"""
        try:
            import requests
            ollama_url = normalize_ollama_base_url(self.config.get("ollama_url", "http://localhost:11434"))
            api_key = self.config.get("ollama_api_key", "")
            headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}

            # Try to connect to Ollama
            response = requests.get(
                f"{ollama_url}/api/tags",
                headers=headers,
                timeout=3
            )

            if response.status_code == 200:
                data = response.json()
                models = []

                # Handle both "models" and direct model list
                model_list = data.get("models", [])

                if model_list:
                    for model in model_list:
                        # Handle both dict and string formats
                        if isinstance(model, dict):
                            name = model.get("name", "Unknown")
                            size = model.get("size", 0)
                        else:
                            name = str(model)
                            size = 0

                        # Clean up name
                        if name and name != "Unknown":
                            display_name = name.split(":")[0].strip()

                            models.append({
                                "name": name,
                                "display_name": display_name,
                                "backend": "ollama",
                                "size": size,
                            })

                return models
            else:
                print(f"Ollama API error: {response.status_code}")
                return []

        except requests.exceptions.ConnectionError:
            print("Cannot connect to Ollama - is it running?")
            return []
        except requests.exceptions.Timeout:
            print("Ollama connection timed out")
            return []
        except Exception as e:
            print(f"Error fetching Ollama models: {e}")
            return []

    def get_together_models(self) -> List[Dict[str, str]]:
        """Get available Together.ai models"""
        models = []
        for model_id, display_name in self.TOGETHER_MODELS.items():
            models.append({
                "name": model_id,
                "display_name": display_name,
                "backend": "together",
            })
        return models

    def get_all_models(self, backend: Optional[str] = None) -> List[Dict[str, str]]:
        """Get all available models, optionally filtered by backend"""
        all_models = []

        # Get Ollama models
        try:
            all_models.extend(self.get_ollama_models())
        except Exception:
            pass

        # Get Together.ai models
        try:
            all_models.extend(self.get_together_models())
        except Exception:
            pass

        # Filter by backend if specified
        if backend:
            all_models = [m for m in all_models if m["backend"] == backend]

        return all_models

    def verify_model_available(self, backend: str, model_name: str) -> bool:
        """Check if a specific model is available"""
        models = self.get_all_models(backend)
        return any(m["name"] == model_name for m in models)

    def get_model_info(self, backend: str, model_name: str) -> Optional[Dict]:
        """Get info about a specific model"""
        models = self.get_all_models(backend)
        for model in models:
            if model["name"] == model_name:
                return model
        return None


class ModelValidator:
    """Validate model configuration"""

    def __init__(self, model_manager: ModelManager):
        self.model_manager = model_manager

    def validate_ollama_config(self) -> tuple[bool, str]:
        """Check if Ollama is running and accessible"""
        try:
            models = self.model_manager.get_ollama_models()
            if models:
                return True, f"✓ Ollama running ({len(models)} models found)"
            else:
                return False, "✗ Ollama not responding with models"
        except Exception as e:
            if "ConnectionError" in type(e).__name__:
                return False, "✗ Cannot connect to Ollama. Is it running?"
            return False, f"✗ Ollama error: {str(e)}"

    def validate_together_config(self, api_key: str) -> tuple[bool, str]:
        """Check if Together.ai API key is valid"""
        if not api_key:
            return False, "✗ No API key provided"

        try:
            import requests
            response = requests.get(
                "https://api.together.xyz/inference",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=5
            )

            if response.status_code == 401:
                return False, "✗ Invalid Together.ai API key"
            elif response.status_code == 200:
                return True, "✓ Together.ai API key valid"
            else:
                return False, f"✗ Together.ai error: {response.status_code}"

        except requests.exceptions.ConnectionError:
            return False, "✗ Cannot connect to Together.ai (no internet?)"
        except Exception as e:
            return False, f"✗ API validation error: {str(e)}"
