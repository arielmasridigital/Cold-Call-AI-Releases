"""
Cold Call AI — local-first auth / syllabus manager.

Syllabus text lives on disk at ~/.coldcallai/syllabus.txt (written by the app's
in-panel PDF uploader). We prefer reading it locally on every cold call so the
app works offline, without a website round-trip.

Account linking is kept around as a thin browser hand-off that's only needed
for paid features (Pro / Stripe). Everyday use doesn't require it.
"""

import http.server
import json
import socketserver
import threading
import time
import webbrowser
from pathlib import Path
from typing import Optional, List, Dict, Any
from urllib.parse import parse_qs, urlparse

# Kept for reference / future Stripe hand-off. Not hit on the hot path.
WEB_BASE_URL = "https://cold-call-ai.vercel.app"


class AuthHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        query_components = parse_qs(urlparse(self.path).query)
        if "token" in query_components:
            self.server.token = query_components["token"][0]
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(
                b"<html><body style='font-family:sans-serif;text-align:center;"
                b"padding-top:50px;background:#001428;color:#d0e4ff;'>"
            )
            self.wfile.write(
                b"<h1 style='color:#9bcbf8'>Login Successful</h1>"
                b"<p>You can close this window and return to Cold Call AI.</p>"
                b"</body></html>"
            )

            def delayed_shutdown():
                time.sleep(2)
                self.server.shutdown()

            threading.Thread(target=delayed_shutdown, daemon=True).start()

    def log_message(self, *args, **kwargs):
        # Keep stdout clean
        pass


class AuthManager:
    def __init__(self):
        self.auth_dir = Path.home() / ".coldcallai"
        self.auth_dir.mkdir(parents=True, exist_ok=True)
        self.token_file = self.auth_dir / "session.json"
        self.syllabus_file = self.auth_dir / "syllabus.txt"

    # ── Local syllabus ───────────────────────────────────────────────────────

    def has_local_syllabus(self) -> bool:
        return self.syllabus_file.exists() and self.syllabus_file.stat().st_size > 0

    def get_syllabus_context(self) -> str:
        """Return the locally cached syllabus text, or empty string if none."""
        if self.has_local_syllabus():
            try:
                return self.syllabus_file.read_text(encoding="utf-8")
            except Exception:
                return ""
        return ""

    def clear_syllabus(self):
        if self.syllabus_file.exists():
            self.syllabus_file.unlink()

    # ── Optional web account link (for Pro / Stripe only) ────────────────────

    def is_logged_in(self) -> bool:
        if not self.token_file.exists():
            return False
        try:
            return "token" in json.loads(self.token_file.read_text())
        except Exception:
            return False

    def get_token(self) -> Optional[str]:
        """Return the stored Firebase ID token, or None if not signed in.

        The token is short-lived (≈1 hour). Callers that hit the cloud API
        should tolerate 401 responses by silently no-op'ing — the user can
        re-link the desktop from the website if cloud sync drifts."""
        if not self.token_file.exists():
            return None
        try:
            return json.loads(self.token_file.read_text()).get("token")
        except Exception:
            return None

    def login(self) -> bool:
        """Browser hand-off for account linking. Only needed for Pro features."""
        port = 8765
        try:
            server = socketserver.TCPServer(("", port), AuthHandler)
        except OSError:
            return False
        server.token = None
        webbrowser.open(f"{WEB_BASE_URL}/desktop-auth?port={port}")
        server.serve_forever()
        if server.token:
            self.token_file.write_text(json.dumps({"token": server.token}))
            return True
        return False

    def logout(self):
        if self.token_file.exists():
            self.token_file.unlink()
