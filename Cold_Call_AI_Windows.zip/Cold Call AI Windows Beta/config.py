import json
from pathlib import Path
from account_policy import (
    FREE_TIER_TOGETHER_MODEL,
    apply_automatic_model_routing,
    is_admin_email,
)


class Config:
    """Handle application configuration"""

    def __init__(self):
        self.config_dir = Path.home() / ".coldcallai"
        self.config_file = self.config_dir / "config.json"
        self.data = self._load_config()

    def _load_config(self):
        if not self.config_dir.exists():
            self.config_dir.mkdir(parents=True)

        if self.config_file.exists():
            try:
                with open(self.config_file, "r") as f:
                    data = json.load(f)
                    # Migrations / Updates
                    defaults = self._default_config()
                    updated = False
                    for k, v in defaults.items():
                        if k not in data:
                            data[k] = v
                            updated = True
                    if not data.get("startup_defaults_v2"):
                        data["listen_enabled"] = False
                        data["audio_mode"] = "in_person"
                        data["meeting_mode"] = False
                        data["auto_detect_meetings"] = False
                        data["startup_defaults_v2"] = True
                        updated = True
                    if not data.get("startup_defaults_v3"):
                        # Existing installs may still have launch-time listening
                        # enabled from older builds. Force it off once so the app
                        # never records class audio until the student explicitly
                        # presses In-Person or Online Class.
                        data["listen_enabled"] = False
                        data["startup_defaults_v3"] = True
                        updated = True
                    if not data.get("startup_defaults_v4"):
                        # English-only Whisper models are faster and more accurate
                        # for the app's classroom use case than multilingual base.
                        if data.get("whisper_model", "base") in ("base", "tiny"):
                            data["whisper_model"] = "base.en"
                        data["startup_defaults_v4"] = True
                        updated = True
                    if self._infer_name_from_email(data):
                        updated = True
                    if apply_automatic_model_routing(data):
                        updated = True
                    if updated:
                        self.save(data)
                    return data
            except:
                return self._default_config()
        else:
            config = self._default_config()
            self.save(config)
            return config

    def _default_config(self):
        return {
            "user_name": "Ariel",
            "trigger_keywords": "explain, question, what, how",
            "listen_enabled": False,
            "provider": "together",                      # 'ollama' or 'together'
            "together_model": FREE_TIER_TOGETHER_MODEL,
            "together_api_key": "",
            "ollama_url": "http://localhost:11434",
            "ollama_model": "mistral",
            "ollama_api_key": "",
            "context_size": 5,
            "cold_call_context_chars": 5500,
            "session_transcript_chunk_limit": 10000,
            "note_transcript_storage_chars": 160000,
            "response_timeout": 10,
            "stt_provider": "auto",                        # 'auto', 'google', or 'whisper'
            "whisper_model": "base.en",                    # 'tiny.en', 'base.en', 'small.en'
            "confidence_threshold": 0.7,
            "theme": "dark",
            "overlay_timeout": 18,
            "email": "",
            "audio_mode": "in_person",                    # 'in_person' or 'online'
            "meeting_mode": False,
            "auto_detect_meetings": False,
            "screen_recording_permission_prompted": False,
            "screen_recording_permission_granted": False,
            "permissions_preflight_version": "",
            "answer_cooldown_seconds": 12,
            "plan": "free",
            "plan_name": "Flurry",
            "is_premium": False,
            "is_per_call": False,
            "is_admin": False,
            "active_class_id": "",
            "class_name": "",
            "class_notes": "",
            "course_profiles": [],
            "model_routing": "automatic",
            "allow_model_switching": False,
            "startup_defaults_v2": True,
            "startup_defaults_v3": True,
            "startup_defaults_v4": True,
            "desktop_tutorial_seen": False,
            "desktop_tutorial_version": "",
            "prep_notes": "",
            "class_note_archive": [],
            "frost_meter_current_cents": 0,
            "frost_meter_lifetime_cents": 0,
            "frost_meter_call_count": 0,
        }

    def _infer_name_from_email(self, data: dict) -> bool:
        current = str(data.get("user_name", "") or "").strip()
        if current and current.lower() != "ariel":
            return False
        email = str(data.get("email", "") or "").strip()
        if "@" not in email:
            return False
        local = email.split("@", 1)[0].replace(".", " ").replace("_", " ").replace("-", " ")
        candidate = " ".join(part.capitalize() for part in local.split() if part)
        if not candidate:
            return False
        if current == candidate:
            return False
        data["user_name"] = candidate
        return True

    def save(self, data=None):
        if data:
            self.data = data
        with open(self.config_file, "w") as f:
            json.dump(self.data, f, indent=4)

    def get(self, key, default=None):
        return self.data.get(key, default)

    def set(self, key, value):
        self.data[key] = value
        self.save()

    def reload(self):
        self.data = self._load_config()

    def sync_from_cloud(self, token: str) -> tuple[bool, str]:
        """Fetch settings from the web dashboard profile"""
        try:
            import requests
            resp = requests.get(
                "https://cold-call-ai.vercel.app/api/profile",
                headers={"Authorization": f"Bearer {token}"},
                timeout=10
            )
            if resp.status_code == 200:
                profile = resp.json().get("profile", {})
                updated = False
                
                # Together API Key sync
                web_key = profile.get("togetherApiKey")
                if web_key and web_key != self.data.get("together_api_key"):
                    self.data["together_api_key"] = web_key
                    updated = True
                web_provider = profile.get("aiProvider")
                if web_provider in ("together", "ollama") and web_provider != self.data.get("provider"):
                    self.data["provider"] = web_provider
                    updated = True
                web_ollama_url = profile.get("ollamaUrl")
                if web_ollama_url and web_ollama_url != self.data.get("ollama_url"):
                    self.data["ollama_url"] = web_ollama_url
                    updated = True
                web_ollama_model = profile.get("ollamaModel")
                if web_ollama_model and web_ollama_model != self.data.get("ollama_model"):
                    self.data["ollama_model"] = web_ollama_model
                    updated = True
                web_ollama_key = profile.get("ollamaApiKey")
                if web_ollama_key and web_ollama_key != self.data.get("ollama_api_key"):
                    self.data["ollama_api_key"] = web_ollama_key
                    updated = True

                web_email = profile.get("email")
                if web_email and web_email != self.data.get("email"):
                    self.data["email"] = web_email
                    updated = True
                web_admin = bool(profile.get("isAdmin", False)) or is_admin_email(web_email)
                if web_admin != bool(self.data.get("is_admin", False)):
                    self.data["is_admin"] = web_admin
                    updated = True
                allow_switching = bool(profile.get("allowModelSwitching", False)) or web_admin
                if allow_switching != bool(self.data.get("allow_model_switching", False)):
                    self.data["allow_model_switching"] = allow_switching
                    updated = True

                web_plan = profile.get("plan") or "free"
                plan_names = {
                    "free": "Flurry",
                    "core": "Iceberg",
                    "pro": "Iceberg",
                    "max": "Glacier",
                    "per_call": "Frost Meter",
                }
                web_premium = bool(profile.get("isPremium", False)) or web_plan != "free"
                web_per_call = bool(profile.get("isPerCall", False)) or web_plan == "per_call"
                if web_premium != bool(self.data.get("is_premium", False)):
                    self.data["is_premium"] = web_premium
                    updated = True
                if web_per_call != bool(self.data.get("is_per_call", False)):
                    self.data["is_per_call"] = web_per_call
                    updated = True
                if web_plan != self.data.get("plan"):
                    self.data["plan"] = web_plan
                    updated = True
                plan_name = plan_names.get(web_plan, "Flurry")
                if plan_name != self.data.get("plan_name"):
                    self.data["plan_name"] = plan_name
                    updated = True

                web_credits = profile.get("credits")
                if isinstance(web_credits, int) and web_credits != self.data.get("credits_total"):
                    self.data["credits_total"] = web_credits
                    updated = True

                frost_current = profile.get("frostMeterCurrentCents")
                if isinstance(frost_current, int) and frost_current != self.data.get("frost_meter_current_cents"):
                    self.data["frost_meter_current_cents"] = frost_current
                    updated = True
                frost_lifetime = profile.get("frostMeterLifetimeCents")
                if isinstance(frost_lifetime, int) and frost_lifetime != self.data.get("frost_meter_lifetime_cents"):
                    self.data["frost_meter_lifetime_cents"] = frost_lifetime
                    updated = True
                frost_calls = profile.get("frostMeterCallCount")
                if isinstance(frost_calls, int) and frost_calls != self.data.get("frost_meter_call_count"):
                    self.data["frost_meter_call_count"] = frost_calls
                    updated = True

                # End users do not choose models. The app routes automatically by plan.
                if not self.data.get("allow_model_switching", False):
                    if apply_automatic_model_routing(self.data):
                        updated = True

                # User name — prefer settings page userName over displayName
                web_username = profile.get("userName") or profile.get("displayName")
                if web_username and web_username != self.data.get("user_name"):
                    self.data["user_name"] = web_username
                    updated = True
                elif self._infer_name_from_email(self.data):
                    updated = True

                # Class / course name
                web_class = profile.get("className")
                if web_class is not None and web_class != self.data.get("class_name"):
                    self.data["class_name"] = web_class
                    updated = True
                web_active_class_id = profile.get("activeClassId")
                if web_active_class_id is not None and web_active_class_id != self.data.get("active_class_id"):
                    self.data["active_class_id"] = web_active_class_id
                    updated = True
                web_classes = profile.get("classes")
                if isinstance(web_classes, list) and web_classes != self.data.get("course_profiles"):
                    self.data["course_profiles"] = web_classes
                    updated = True
                active_notes = ""
                if isinstance(web_classes, list) and web_active_class_id:
                    for item in web_classes:
                        if isinstance(item, dict) and item.get("id") == web_active_class_id:
                            active_notes = item.get("notes", "") or ""
                            break
                if active_notes != self.data.get("class_notes"):
                    self.data["class_notes"] = active_notes
                    updated = True

                # Trigger keywords
                web_kw = profile.get("triggerKeywords")
                if web_kw and web_kw != self.data.get("trigger_keywords"):
                    self.data["trigger_keywords"] = web_kw
                    updated = True

                web_notes = profile.get("prepNotes")
                if web_notes is not None and web_notes != self.data.get("prep_notes"):
                    self.data["prep_notes"] = web_notes
                    updated = True

                if updated:
                    self.save()
                    return True, "Settings synced from cloud."
                return True, "Already up to date."
            else:
                return False, f"Cloud sync failed ({resp.status_code})"
        except Exception as e:
            return False, f"Sync error: {e}"
