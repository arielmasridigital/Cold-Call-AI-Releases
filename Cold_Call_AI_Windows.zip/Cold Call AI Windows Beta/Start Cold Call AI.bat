@echo off
setlocal
cd /d "%~dp0"

echo Starting Cold Call AI Windows Beta...
echo.

where py >nul 2>&1
if %errorlevel%==0 (
  set PYTHON_CMD=py -3
) else (
  set PYTHON_CMD=python
)

if not exist ".venv\Scripts\activate.bat" (
  echo Creating local Python environment...
  %PYTHON_CMD% -m venv .venv
  if errorlevel 1 goto python_error
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r requirements-windows.txt
python cold_call_ai_win.py
goto end

:python_error
echo.
echo Could not create a Python environment. Install Python 3.10+ from https://python.org and try again.
pause

:end
endlocal
