Cold Call AI Windows Beta

This package contains the Windows desktop beta source and build helper.

For users:
1. Run "Start Cold Call AI.bat".
2. Windows will create a local .venv folder, install dependencies, and open the app.
3. Use Online mode to capture system audio loopback when available, or Mic mode as fallback.

For release builders:
1. Open this folder on a Windows machine or Windows VM.
2. Run build_windows.bat.
3. Upload dist_win\Cold_Call_AI_Windows.zip or dist_win\Cold_Call_AI_Setup.exe.

Note: macOS cannot produce a native Windows .exe because PyInstaller needs the Windows bootloader and DLL graph. The website serves this Windows beta ZIP until a Windows CI runner publishes the installer automatically.
