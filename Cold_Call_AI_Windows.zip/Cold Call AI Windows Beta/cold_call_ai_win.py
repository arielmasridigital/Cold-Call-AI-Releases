#!/usr/bin/env python3
"""
Cold Call AI — Windows Edition
Uses tkinter instead of AppKit for the overlay and settings.
System tray via pystray.
"""

import os, json, threading, queue, sys, time, webbrowser
from pathlib import Path

# ── Lazy-loaded heavy deps ────────────────────────────────────────────────────
def _import_sr():
    import speech_recognition as sr
    return sr

try:
    import speech_recognition as _sr_base
    _AUDIO_SOURCE_BASE = _sr_base.AudioSource
except Exception:
    _AUDIO_SOURCE_BASE = object

def _import_requests():
    import requests
    return requests

def _import_np():
    import numpy as np
    return np

def _import_soundcard():
    import soundcard as sc
    return sc

# ── Windows Tray Icon ─────────────────────────────────────────────────────────
try:
    import pystray
    from PIL import Image as PILImage
    HAS_TRAY = True
except ImportError:
    HAS_TRAY = False

# ── Overlay using tkinter ─────────────────────────────────────────────────────
import tkinter as tk
from tkinter import font as tkfont, filedialog, messagebox

APP_VERSION = "1.1.64"
COLD_CALL_RECENT_CONTEXT_CHARS = 5500
COLD_CALL_COURSE_CHARS = 3500
COLD_CALL_PREP_CHARS = 1800

BG_COLOR   = "#001428"
CARD_COLOR = "#0C2135"
CYAN       = "#9bcbf8"
BLUE       = "#afc8f0"
WHITE      = "#d0e4ff"
MUTED      = "#8899aa"
ERR        = "#ffb4ab"

class AnswerOverlay:
    def __init__(self):
        self.root = None

    def show(self, question: str, answer: str, duration: int = 18):
        if self.root:
            self.root.destroy()
        t = threading.Thread(target=self._run, args=(question, answer, duration), daemon=True)
        t.start()

    def _run(self, question, answer, duration):
        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.attributes("-alpha", 0.94)
        self.root.configure(bg=BG_COLOR)

        sw = self.root.winfo_screenwidth()
        W, H = 480, 200
        x = sw - W - 20
        self.root.geometry(f"{W}x{H}+{x}+80")

        hdr = tk.Frame(self.root, bg="#001F3F", height=38)
        hdr.pack(fill="x")
        tk.Label(hdr, text="🧊  COLD CALL AI  ·  Response Ready", bg="#001F3F", fg=CYAN, font=("Inter", 9, "bold")).pack(side="left", padx=14, pady=9)
        tk.Button(hdr, text="✕", bg="#001F3F", fg=MUTED, bd=0, font=("Inter",10), command=self.hide).pack(side="right", padx=10)

        body = tk.Frame(self.root, bg=BG_COLOR)
        body.pack(fill="both", expand=True, padx=14, pady=8)
        tk.Label(body, text="PROFESSOR SAID:", bg=BG_COLOR, fg=MUTED, font=("Inter", 7, "bold")).pack(anchor="w")
        tk.Label(body, text=f'"{question[:120]}"', bg=BG_COLOR, fg=BLUE, font=("Inter", 11), wraplength=450, justify="left").pack(anchor="w")
        tk.Frame(body, bg=CYAN, height=1).pack(fill="x", pady=5)
        tk.Label(body, text="YOUR ANSWER:", bg=BG_COLOR, fg=CYAN, font=("Inter", 7, "bold")).pack(anchor="w")
        tk.Label(body, text=answer[:400], bg=BG_COLOR, fg=WHITE, font=("Inter", 12), wraplength=450, justify="left").pack(anchor="w")

        if duration > 0: self.root.after(duration * 1000, self.hide)
        self.root.mainloop()

    def hide(self):
        if self.root: self.root.destroy(); self.root = None

class WindowsSettings:
    def __init__(self, app_ref):
        self.app = app_ref
        self.root = None

    def show(self):
        if self.root: self.root.focus(); return
        self.root = tk.Toplevel()
        self.root.title("Cold Call AI Settings")
        self.root.geometry("400x500")
        self.root.configure(bg=BG_COLOR)
        self.root.attributes("-topmost", True)
        
        tk.Label(self.root, text="ICEBERG SETTINGS", bg=BG_COLOR, fg=CYAN, font=("Inter", 12, "bold")).pack(pady=20)
        
        # Together Key
        tk.Label(self.root, text="Together.ai API Key", bg=BG_COLOR, fg=WHITE).pack(anchor="w", padx=20)
        self.key_ent = tk.Entry(self.root, bg=CARD_COLOR, fg=WHITE, insertbackground=WHITE, bd=0)
        self.key_ent.pack(fill="x", padx=20, pady=5, ipady=5)
        self.key_ent.insert(0, self.app.config.get("together_api_key", ""))

        # User Name
        tk.Label(self.root, text="Your Name", bg=BG_COLOR, fg=WHITE).pack(anchor="w", padx=20, pady=(10,0))
        self.name_ent = tk.Entry(self.root, bg=CARD_COLOR, fg=WHITE, insertbackground=WHITE, bd=0)
        self.name_ent.pack(fill="x", padx=20, pady=5, ipady=5)
        self.name_ent.insert(0, self.app.config.get("user_name", "Ariel"))

        # Provider
        tk.Label(self.root, text="Provider (together/ollama)", bg=BG_COLOR, fg=WHITE).pack(anchor="w", padx=20, pady=(10,0))
        self.prov_ent = tk.Entry(self.root, bg=CARD_COLOR, fg=WHITE, insertbackground=WHITE, bd=0)
        self.prov_ent.pack(fill="x", padx=20, pady=5, ipady=5)
        self.prov_ent.insert(0, self.app.config.get("provider", "together"))

        # Save Button
        tk.Button(self.root, text="SAVE SETTINGS", bg="#003a5c", fg=CYAN, bd=0, font=("Inter", 10, "bold"), command=self.save).pack(pady=30, padx=20, fill="x", ipady=10)
        
        # Sync Button
        tk.Button(self.root, text="🔄 SYNC FROM WEB", bg=CARD_COLOR, fg=BLUE, bd=0, command=self.sync).pack(pady=5, padx=20, fill="x")

    def save(self):
        self.app.config.data["together_api_key"] = self.key_ent.get()
        self.app.config.data["user_name"] = self.name_ent.get()
        self.app.config.data["provider"] = self.prov_ent.get()
        self.app.config.save()
        messagebox.showinfo("Cold Call AI", "Settings saved successfully!")
        self.root.destroy(); self.root = None

    def sync(self):
        from auth import AuthManager
        auth = AuthManager()
        if not auth.is_logged_in():
            messagebox.showerror("Error", "Please sign in from the main panel first.")
            return
        with open(auth.token_file) as f:
            token = json.load(f)["token"]
        ok, msg = self.app.config.sync_from_cloud(token)
        if ok:
            self.key_ent.delete(0, tk.END); self.key_ent.insert(0, self.app.config.get("together_api_key", ""))
            self.name_ent.delete(0, tk.END); self.name_ent.insert(0, self.app.config.get("user_name", ""))
            messagebox.showinfo("Sync", msg)
        else:
            messagebox.showerror("Sync", msg)

class ControlPanel:
    def __init__(self, app_ref):
        self.app = app_ref
        self.root = None
        self.settings = WindowsSettings(app_ref)

    def toggle(self):
        if self.root: self.root.destroy(); self.root = None
        else: self._build()

    def _build(self):
        self.root = tk.Toplevel()
        self.root.title("Cold Call AI — Command Panel")
        self.root.configure(bg=BG_COLOR); self.root.geometry("340x460")
        self.root.attributes("-topmost", True)
        
        hdr = tk.Frame(self.root, bg="#001F3F", height=44); hdr.pack(fill="x")
        tk.Label(hdr, text="COLD CALL  ·  Command Panel", bg="#001F3F", fg=CYAN, font=("Inter",10,"bold")).pack(side="left", padx=14, pady=12)

        pad = tk.Frame(self.root, bg=BG_COLOR); pad.pack(fill="x", padx=14, pady=(12,4))
        tk.Label(pad, text="SESSION STATUS", bg=BG_COLOR, fg=MUTED, font=("Inter",7,"bold")).pack(anchor="w")

        row = tk.Frame(self.root, bg=CARD_COLOR); row.pack(fill="x", padx=14, pady=4)
        self.status_lbl = tk.Label(row, text="⚪  Idle", bg=CARD_COLOR, fg=WHITE, font=("Inter",11)); self.status_lbl.pack(side="left", padx=10, pady=8)

        def toggle_mic():
            if self.app.listening: self.app.stop_listening()
            else: self.app.start_listening("microphone")

        def toggle_online():
            if self.app.listening: self.app.stop_listening()
            else: self.app.start_online_class_mode()

        tk.Button(row, text="🎙 MIC", bg="#003a5c", fg=CYAN, bd=0, font=("Inter",8,"bold"), command=toggle_mic).pack(side="right", padx=4, pady=6)
        tk.Button(row, text="🖥 ONLINE", bg="#071D30", fg=BLUE, bd=0, font=("Inter",8,"bold"), command=toggle_online).pack(side="right", padx=4, pady=6)
        tk.Frame(self.root, bg=CYAN, height=1).pack(fill="x", padx=14, pady=8)

        tk.Label(self.root, text="COURSE MATERIALS", bg=BG_COLOR, fg=MUTED, font=("Inter",7,"bold")).pack(anchor="w", padx=14)
        up_row = tk.Frame(self.root, bg=CARD_COLOR); up_row.pack(fill="x", padx=14, pady=4)
        tk.Label(up_row, text="📄  PDF Syllabus", bg=CARD_COLOR, fg=MUTED, font=("Inter",10)).pack(side="left", padx=8, pady=10)
        self.up_status = tk.StringVar(value="")
        tk.Button(up_row, text="BROWSE", bg="#003a5c", fg=CYAN, bd=0, font=("Inter",9,"bold"), command=self._upload).pack(side="right", padx=8, pady=8)
        tk.Label(self.root, textvariable=self.up_status, bg=BG_COLOR, fg=CYAN, font=("Inter",8)).pack(anchor="w", padx=14)

        tk.Frame(self.root, bg=CYAN, height=1).pack(fill="x", padx=14, pady=8)
        tk.Button(self.root, text="⚡  ACTIVATE PANIC MODE", bg="#93000a", fg=ERR, bd=0, font=("Inter",10,"bold"), command=lambda: webbrowser.open("https://cold-call-ai.vercel.app/dashboard")).pack(fill="x", padx=14, pady=4, ipady=8)

        btn_row = tk.Frame(self.root, bg=BG_COLOR); btn_row.pack(fill="x", padx=14, pady=4)
        tk.Button(btn_row, text="⚙  Settings", bg="#071D30", fg=MUTED, bd=0, font=("Inter",9), width=14, command=self.settings.show).pack(side="left")
        tk.Button(btn_row, text="🌐  Dashboard", bg="#071D30", fg=MUTED, bd=0, font=("Inter",9), width=14, command=lambda: webbrowser.open("https://cold-call-ai.vercel.app/dashboard")).pack(side="right")

    def set_session_state(self, active: bool, text=None):
        if not self.root or not getattr(self, "status_lbl", None):
            return
        label = text or ("🟢  Session Active" if active else "⚪  Idle")
        color = CYAN if active else MUTED
        try:
            self.root.after(0, lambda: self.status_lbl.config(text=label, fg=color))
        except Exception:
            pass

    def _upload(self):
        path = filedialog.askopenfilename(filetypes=[("PDF Files", "*.pdf")])
        if not path: return
        self.up_status.set("⏳ Uploading PDF...")
        threading.Thread(target=self._do_upload, args=(path,), daemon=True).start()

    def _do_upload(self, path):
        try:
            r = _import_requests()
            token_file = Path.home() / ".coldcallai" / "session.json"
            if not token_file.exists(): self.up_status.set("❌ Link account first."); return
            with open(token_file) as f: token = json.load(f)["token"]
            with open(path, "rb") as f:
                resp = r.post("https://cold-call-ai.vercel.app/api/upload", headers={"Authorization": f"Bearer {token}"}, files={"file": (Path(path).name, f, "application/pdf")}, timeout=60)
            if resp.status_code == 200: self.up_status.set("✅ Syllabus linked!"); self.app.config.reload()
            else: self.up_status.set(f"❌ Failed ({resp.status_code})")
        except Exception as e: self.up_status.set(f"❌ Error: {str(e)[:50]}")


class WindowsLoopbackStream:
    """SpeechRecognition-compatible stream that reads Windows system audio."""

    def __init__(self, sample_rate=16000):
        self.sample_rate = sample_rate
        self._recorder_cm = None
        self._recorder = None

    def start(self):
        sc = _import_soundcard()
        speaker = sc.default_speaker()
        loopback = sc.get_microphone(speaker.name, include_loopback=True)
        self._recorder_cm = loopback.recorder(samplerate=self.sample_rate, channels=1)
        self._recorder = self._recorder_cm.__enter__()
        return self

    def read(self, size):
        if not self._recorder:
            return b"\x00" * size
        np = _import_np()
        frames = max(1, int(size / 2))
        data = self._recorder.record(numframes=frames)
        if getattr(data, "ndim", 1) > 1:
            data = data.mean(axis=1)
        pcm = (np.clip(data, -1.0, 1.0) * 32767).astype(np.int16).tobytes()
        if len(pcm) < size:
            pcm += b"\x00" * (size - len(pcm))
        return pcm[:size]

    def close(self):
        if self._recorder_cm:
            try:
                self._recorder_cm.__exit__(None, None, None)
            except Exception:
                pass
        self._recorder_cm = None
        self._recorder = None


class WindowsLoopbackSource(_AUDIO_SOURCE_BASE):
    """AudioSource for Zoom/Teams/Meet/system audio on Windows."""

    def __init__(self):
        self.SAMPLE_RATE = 16000
        self.SAMPLE_WIDTH = 2
        self.CHUNK = 1024
        self.stream = None

    def __enter__(self):
        self.stream = WindowsLoopbackStream(self.SAMPLE_RATE).start()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if self.stream:
            self.stream.close()
        self.stream = None


class WindowsColdCallAIApp:
    """Small Windows beta runtime that avoids macOS AppKit imports."""

    def __init__(self):
        from config import Config

        self.config = Config()
        self.overlay = AnswerOverlay()
        self.panel = ControlPanel(self)
        self.listening = False
        self._thread = None
        self._stop = threading.Event()
        self.audio_mode = "microphone"
        self.session_notes = []

    def start_listening(self, mode="microphone"):
        if self.listening:
            return
        self.audio_mode = mode
        self.listening = True
        self._stop.clear()
        label = "🖥  Online Class" if mode == "online" else "🎙  Mic Session"
        self.panel.set_session_state(True, label)
        self._thread = threading.Thread(target=self._listen_loop, args=(mode,), daemon=True)
        self._thread.start()

    def start_online_class_mode(self):
        self.start_listening("online")

    def stop_listening(self):
        self.listening = False
        self._stop.set()
        self.panel.set_session_state(False)

    def _listen_loop(self, mode="microphone"):
        try:
            sr = _import_sr()
            recognizer = sr.Recognizer()
            source_factory = WindowsLoopbackSource if mode == "online" else sr.Microphone
            try:
                with source_factory() as source:
                    recognizer.adjust_for_ambient_noise(source, duration=0.8)
            except Exception as e:
                if mode != "online":
                    raise
                print(f"[WindowsAudio] Loopback unavailable, falling back to mic: {e}")
                source_factory = sr.Microphone
                with source_factory() as source:
                    recognizer.adjust_for_ambient_noise(source, duration=0.8)
            while not self._stop.is_set():
                try:
                    with source_factory() as source:
                        audio = recognizer.listen(source, timeout=1, phrase_time_limit=14)
                    text = recognizer.recognize_google(audio)
                    if text:
                        self.session_notes.append(text)
                        if len(self.session_notes) > 10000:
                            self.session_notes = self.session_notes[-10000:]
                    if self._should_answer(text):
                        answer = self._answer(text)
                        self.overlay.show(text, answer)
                except sr.WaitTimeoutError:
                    continue
                except Exception as e:
                    print(f"[WindowsAudio] {e}")
                    time.sleep(1)
        finally:
            self.listening = False
            self.panel.set_session_state(False)

    def _should_answer(self, text: str) -> bool:
        lowered = text.lower()
        name = str(self.config.get("user_name", "") or "").strip().lower()
        if name and name in lowered:
            return True
        keywords = str(self.config.get("trigger_keywords", "") or "")
        return any(k.strip().lower() in lowered for k in keywords.split(",") if k.strip())

    def _tail_text(self, text: str, max_chars: int) -> str:
        text = str(text or "").strip()
        return text if len(text) <= max_chars else text[-max_chars:].lstrip()

    def _clip_middle(self, text: str, max_chars: int) -> str:
        text = str(text or "").strip()
        if len(text) <= max_chars:
            return text
        head = max_chars // 3
        tail = max_chars - head - 80
        return text[:head].rstrip() + "\n\n...[middle omitted for speed]...\n\n" + text[-tail:].lstrip()

    def _recent_lecture_context(self) -> str:
        transcript = "\n".join(self.session_notes[:-1])
        return self._tail_text(transcript, COLD_CALL_RECENT_CONTEXT_CHARS)

    def _answer(self, question: str) -> str:
        api_key = self.config.get("together_api_key", "")
        if not api_key:
            return "I heard the question, but your Together.ai key is not synced yet. Open Settings and sync from web."
        try:
            r = _import_requests()
            context = self.config.get("syllabus_context", "")
            prep = self.config.get("prep_notes", "")
            recent = self._recent_lecture_context()
            prompt = (
                "You are Cold Call AI. Give a concise, confident classroom answer. "
                "Start with the direct answer, then one supporting sentence.\n\n"
            )
            if context:
                prompt += f"Course materials (trimmed):\n{self._clip_middle(context, COLD_CALL_COURSE_CHARS)}\n\n"
            if prep:
                prompt += f"Student prep notes (trimmed):\n{self._clip_middle(prep, COLD_CALL_PREP_CHARS)}\n\n"
            if recent:
                prompt += f"Recent lecture context:\n{recent}\n\n"
            prompt += f"Question: {question}\nAnswer:"

            resp = r.post(
                "https://api.together.xyz/v1/chat/completions",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json={
                    "model": self.config.get("together_model", "meta-llama/Llama-3.1-8B-Instruct-Turbo"),
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 180,
                    "temperature": 0.35,
                },
                timeout=20,
            )
            if resp.status_code != 200:
                return f"AI request failed ({resp.status_code}). Try syncing settings or checking your plan."
            return resp.json()["choices"][0]["message"]["content"].strip()
        except Exception as e:
            return f"AI answer failed: {str(e)[:160]}"


# ── Entry Point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk(); root.withdraw()
    app = WindowsColdCallAIApp()
    app.panel.toggle()
    if HAS_TRAY:
        try:
            img = PILImage.open("logo.png").resize((64, 64))
            icon = pystray.Icon("Cold Call AI", img, menu=pystray.Menu(
                pystray.MenuItem("Command Panel", lambda: app.panel.toggle()),
                pystray.MenuItem("Quit", lambda: icon.stop()),
            ))
            icon.run()
        except: root.mainloop()
    else: root.mainloop()
