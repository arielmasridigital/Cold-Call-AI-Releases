"""Shared desktop account policy for admin access and automatic model routing."""

ADMIN_EMAIL_DOMAIN = "@masridigital.com"

FREE_TIER_TOGETHER_MODEL = "meta-llama/Meta-Llama-3-8B-Instruct-Lite"
CORE_TIER_TOGETHER_MODEL = "Qwen/Qwen2.5-7B-Instruct-Turbo"
MAX_TIER_TOGETHER_MODEL = "meta-llama/Llama-3.3-70B-Instruct-Turbo"


def normalize_email(email=None) -> str:
    return (email or "").strip().lower()


def is_admin_email(email=None) -> bool:
    return normalize_email(email).endswith(ADMIN_EMAIL_DOMAIN)


def normalize_plan(plan=None) -> str:
    value = (plan or "free").strip().lower()
    if value in ("core", "pro", "pond"):
        return "core"
    if value in ("plus", "avalanche"):
        return "plus"
    if value in ("max", "glacier"):
        return "max"
    if value == "per_call":
        return "per_call"
    return "free"


def automatic_together_model(plan=None, is_premium: bool = False) -> str:
    normalized = normalize_plan(plan)
    if normalized in ("plus", "max"):
        return MAX_TIER_TOGETHER_MODEL
    if normalized == "core" or is_premium:
        return CORE_TIER_TOGETHER_MODEL
    if normalized == "per_call":
        return MAX_TIER_TOGETHER_MODEL
    return FREE_TIER_TOGETHER_MODEL


def can_choose_models(email=None) -> bool:
    return is_admin_email(email)


def apply_automatic_model_routing(config_data: dict) -> bool:
    """Force regular users onto the server-selected Together model path.

    Returns True when config_data was changed.
    """
    if can_choose_models(config_data.get("email")):
        return False

    # Allow local testing / offline model run with Ollama
    if config_data.get("provider") == "ollama":
        return False

    changed = False
    plan = config_data.get("plan", "free")
    is_premium = bool(config_data.get("is_premium", False))
    routed_model = automatic_together_model(plan, is_premium)

    if config_data.get("provider") != "together":
        config_data["provider"] = "together"
        changed = True
    if config_data.get("together_model") != routed_model:
        config_data["together_model"] = routed_model
        changed = True
    if config_data.get("model_routing") != "automatic":
        config_data["model_routing"] = "automatic"
        changed = True
    if config_data.get("allow_model_switching") is not False:
        config_data["allow_model_switching"] = False
        changed = True

    return changed
