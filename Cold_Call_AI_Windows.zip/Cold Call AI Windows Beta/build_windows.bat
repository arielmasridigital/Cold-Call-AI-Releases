@echo off
REM Cold Call AI — Windows Build Script
REM Creates a Windows .exe installer using PyInstaller
REM Run this from a Windows machine or a Windows VM.
REM Requirements: Python 3.10+, pip, NSIS (optional, for installer)

setlocal enabledelayedexpansion

echo ==================================================
echo  Cold Call AI — Windows Build
echo ==================================================
echo.

set APP_NAME=Cold Call AI
set SCRIPT_DIR=%~dp0
set VENV_DIR=%SCRIPT_DIR%venv_win
set DIST_DIR=%SCRIPT_DIR%dist_win
set BUILD_DIR=%SCRIPT_DIR%build_win

echo [1/6] Checking Python...
python --version
if errorlevel 1 (
    echo ERROR: Python not found. Install from https://python.org
    exit /b 1
)
echo.

echo [2/6] Cleaning previous builds...
rmdir /s /q "%BUILD_DIR%" 2>nul
rmdir /s /q "%DIST_DIR%" 2>nul
rmdir /s /q "%VENV_DIR%" 2>nul
mkdir "%BUILD_DIR%"
mkdir "%DIST_DIR%"
echo Done.
echo.

echo [3/6] Creating virtual environment...
python -m venv "%VENV_DIR%"
call "%VENV_DIR%\Scripts\activate.bat"
echo.

echo [4/6] Installing dependencies...
pip install --quiet --upgrade pip
REM Install Windows-compatible dependencies (no AppKit/pyobjc)
pip install --quiet rumps-stub 2>nul || echo Note: rumps not available on Windows, using stub
pip install --quiet speechrecognition requests pyinstaller pillow pywin32 pystray pyaudio numpy soundcard
echo.

echo [5/6] Building Windows executable...
pyinstaller ^
    --onedir ^
    --windowed ^
    --name "Cold Call AI" ^
    --icon="%SCRIPT_DIR%logo.ico" ^
    --hidden-import="speech_recognition" ^
    --hidden-import="requests" ^
    --hidden-import="numpy" ^
    --hidden-import="soundcard" ^
    --collect-submodules="speech_recognition" ^
    --distpath="%DIST_DIR%" ^
    --workpath="%BUILD_DIR%" ^
    cold_call_ai_win.py

echo.
echo [6/6] Packaging...

REM Create a simple zip installer if NSIS is not available
where makensis >nul 2>&1
if !errorlevel! == 0 (
    echo Found NSIS — building .exe installer...
    REM Write a basic NSIS script
    echo !define APP_NAME "Cold Call AI" > "%BUILD_DIR%\installer.nsi"
    echo !define INSTALLER_NAME "Cold_Call_AI_Setup.exe" >> "%BUILD_DIR%\installer.nsi"
    echo OutFile "%DIST_DIR%\Cold_Call_AI_Setup.exe" >> "%BUILD_DIR%\installer.nsi"
    echo InstallDir "$PROGRAMFILES\Cold Call AI" >> "%BUILD_DIR%\installer.nsi"
    echo Section "Install" >> "%BUILD_DIR%\installer.nsi"
    echo   SetOutPath "$INSTDIR" >> "%BUILD_DIR%\installer.nsi"
    echo   File /r "%DIST_DIR%\Cold Call AI\*" >> "%BUILD_DIR%\installer.nsi"
    echo   CreateShortCut "$DESKTOP\Cold Call AI.lnk" "$INSTDIR\Cold Call AI.exe" >> "%BUILD_DIR%\installer.nsi"
    echo   CreateShortCut "$SMPROGRAMS\Cold Call AI.lnk" "$INSTDIR\Cold Call AI.exe" >> "%BUILD_DIR%\installer.nsi"
    echo SectionEnd >> "%BUILD_DIR%\installer.nsi"
    makensis "%BUILD_DIR%\installer.nsi"
    echo.
    echo SUCCESS: Installer at %DIST_DIR%\Cold_Call_AI_Setup.exe
    powershell -command "Compress-Archive -Path '%DIST_DIR%\Cold Call AI' -DestinationPath '%DIST_DIR%\Cold_Call_AI_Windows.zip' -Force"
    echo SUCCESS: Zip fallback at %DIST_DIR%\Cold_Call_AI_Windows.zip
) else (
    echo NSIS not found — zipping app folder instead...
    powershell -command "Compress-Archive -Path '%DIST_DIR%\Cold Call AI' -DestinationPath '%DIST_DIR%\Cold_Call_AI_Windows.zip' -Force"
    echo SUCCESS: App bundle at %DIST_DIR%\Cold_Call_AI_Windows.zip
)

echo.
echo ==================================================
echo  Build complete!
echo ==================================================
call deactivate
